-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 15, 2025 at 02:37 AM
-- Server version: 10.6.20-MariaDB-cll-lve-log
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yfiniqvq_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `deposits`
--

CREATE TABLE `deposits` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `wallet_id` int(11) NOT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `wallet` varchar(255) NOT NULL,
  `deposit_amt` varchar(255) DEFAULT NULL,
  `return_amt` varchar(255) DEFAULT NULL,
  `from_to` varchar(255) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `crypto_address` varchar(255) DEFAULT NULL,
  `approved` enum('0','1','2') NOT NULL DEFAULT '0',
  `transaction_type` varchar(25) NOT NULL DEFAULT 'deposit',
  `datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deposits`
--

INSERT INTO `deposits` (`id`, `uid`, `wallet_id`, `currency`, `wallet`, `deposit_amt`, `return_amt`, `from_to`, `notes`, `crypto_address`, `approved`, `transaction_type`, `datetime`) VALUES
(58, 33, 1, 'USDT(ERC20)', 'USD', '500', '500.30375', NULL, NULL, '0x420e7955eB650C9cCE17055a7f657F879F0C2Ad4', '1', 'deposit', '2024-03-07 00:11:15'),
(59, 33, 1, 'BNB', 'USD', '1', '251.8', NULL, NULL, '0x420e7955eB650C9cCE17055a7f657F879F0C2Ad4', '1', 'deposit', '2024-03-07 00:15:04'),
(62, 35, 2, 'BTC', 'BTC', '0.5', '0.5', NULL, NULL, 'bc1qdhmv7c6702uhhrshqq9uyfa6sp7g2vzyy0fs97', '1', 'deposit', '2024-05-28 00:40:23'),
(63, 35, 8, 'BTC', 'USDT', '0.1', '6926.64', NULL, NULL, NULL, '1', 'exchange to', '2024-05-28 00:59:00'),
(65, 42, 2, 'BTC', 'BTC', '0.82', '0.82', NULL, NULL, 'bc1qdhmv7c6702uhhrshqq9uyfa6sp7g2vzyy0fs97', '1', 'deposit', '2024-06-03 09:18:59'),
(66, 41, 8, 'USDT(ERC20)', 'USDT', '305', '305', NULL, NULL, '0x420e7955eB650C9cCE17055a7f657F879F0C2Ad4', '1', 'deposit', '2024-06-03 09:49:30'),
(67, 41, 2, 'USDT', 'BTC', '305', '0.00469032', NULL, NULL, NULL, '1', 'exchange to', '2024-06-20 19:49:59'),
(68, 35, 8, 'USDT', 'USDT', '5120', '5120', NULL, NULL, NULL, '1', 'Investment return', '2024-09-09 09:15:31'),
(69, 35, 2, 'BTC', 'BTC', '1', '1', NULL, NULL, 'bc1qdhmv7c6702uhhrshqq9uyfa6sp7g2vzyy0fs97', '1', 'deposit', '2024-11-19 10:44:06'),
(75, 51, 3, 'ETH', 'ETH', '.035', '0.035', NULL, NULL, '0x420e7955eB650C9cCE17055a7f657F879F0C2Ad4', '1', 'deposit', '2024-11-22 16:14:41'),
(76, 35, 3, 'ETH', 'ETH', '1', '1', NULL, NULL, '0x420e7955eB650C9cCE17055a7f657F879F0C2Ad4', '1', 'deposit', '2024-11-22 16:31:22'),
(77, 51, 3, 'ETH', 'ETH', '.032', '0.032', NULL, NULL, '0x420e7955eB650C9cCE17055a7f657F879F0C2Ad4', '1', 'deposit', '2024-11-22 18:21:33'),
(78, 35, 8, 'USDT', 'USDT', '1024', '1024', NULL, NULL, NULL, '1', 'Investment return', '2024-12-01 00:31:06'),
(79, 25, 18, 'USDT(ERC20)', 'AVAX', '500', '9.65437343', NULL, NULL, '0x420e7955eB650C9cCE17055a7f657F879F0C2Ad4', '1', 'deposit', '2024-12-08 14:18:36'),
(80, 52, 1, 'BTC', 'USD', '.005', '500.22833125', NULL, NULL, 'bc1qdhmv7c6702uhhrshqq9uyfa6sp7g2vzyy0fs97', '1', 'deposit', '2024-12-08 16:22:51'),
(81, 52, 1, 'BTC', 'USD', '.00003', '3.00134644', NULL, NULL, 'bc1qdhmv7c6702uhhrshqq9uyfa6sp7g2vzyy0fs97', '1', 'deposit', '2024-12-08 16:23:29'),
(82, 52, 1, 'USDT(TRC20)', 'USD', '5', '5.0027125', NULL, NULL, 'TB8LB4PgHNgEhaiiittpYA7seoPKfdarvp', '1', 'deposit', '2024-12-08 16:23:47'),
(87, 25, 2, 'BTC', 'BTC', '0.089145205479431', '0.089145205479431', NULL, NULL, NULL, '1', 'Stake return', '2024-12-08 19:04:49'),
(88, 51, 3, 'ETH', 'ETH', '0.001608', '0.001608', NULL, NULL, NULL, '1', 'Investment return', '2024-12-08 19:25:04'),
(95, 35, 3, 'ETH', 'ETH', '1.024', '1.024', NULL, NULL, NULL, '1', 'Investment return', '2024-12-09 14:43:54'),
(96, 51, 3, 'ETH', 'ETH', '.067', '.067', NULL, NULL, NULL, '1', 'Investment return', '2024-12-09 16:29:25'),
(101, 25, 1, 'BTC', 'USD', '50.022833125', '50.022833125', 'Nyash Bombom', NULL, NULL, '1', 'ref bonus', '2024-12-09 17:09:59'),
(102, 25, 1, 'USDT(TRC20)', 'USD', '0.50027125', '0.50027125', 'Nyash Bombom', NULL, NULL, '1', 'ref bonus', '2024-12-09 17:10:02'),
(103, 53, 8, 'USDT(TRC20)', 'USDT', '1000', '1000', NULL, NULL, 'TB8LB4PgHNgEhaiiittpYA7seoPKfdarvp', '1', 'deposit', '2024-12-11 00:16:10'),
(104, 35, 8, 'USDT(TRC20)', 'USDT', '100', '100', 'Mia Mia', NULL, NULL, '1', 'ref bonus', '2024-12-11 00:19:33'),
(105, 25, 2, 'BTC', 'BTC', '0.00095342465753424', '0.00095342465753424', NULL, NULL, NULL, '1', 'Stake return', '2024-12-11 13:43:57'),
(106, 37, 2, 'BTC', 'BTC', '0.067', '0.067', NULL, NULL, 'bc1qdhmv7c6702uhhrshqq9uyfa6sp7g2vzyy0fs97', '1', 'deposit', '2024-12-18 00:47:26'),
(107, 25, 2, 'BTC', 'BTC', '0.0033369863013698', '0.0033369863013698', NULL, NULL, NULL, '1', 'Stake return', '2024-12-19 23:01:26'),
(108, 51, 3, 'ETH', 'ETH', '0.070254592', '0.070254592', NULL, NULL, NULL, '1', 'Investment return', '2024-12-29 15:28:19');

-- --------------------------------------------------------

--
-- Table structure for table `investments`
--

CREATE TABLE `investments` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `wid` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `plan` varchar(255) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `usd_val` varchar(255) NOT NULL,
  `to_earn` varchar(255) NOT NULL,
  `earned` varchar(255) NOT NULL DEFAULT '0',
  `expected` varchar(255) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `last_updated` int(11) NOT NULL,
  `phase` enum('first','second','third','fourth','fifth','sixth') NOT NULL,
  `status` enum('active','ended') NOT NULL DEFAULT 'active',
  `num_of_days` int(11) NOT NULL DEFAULT 1,
  `available_withdrawal` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `investments`
--

INSERT INTO `investments` (`id`, `uid`, `wid`, `plan_id`, `plan`, `currency`, `amount`, `usd_val`, `to_earn`, `earned`, `expected`, `start_date`, `end_date`, `last_updated`, `phase`, `status`, `num_of_days`, `available_withdrawal`) VALUES
(3, 25, 1, 1, 'TIER I', 'USD', '200', '200', '0.32', '4.8', '4.8', '2024-02-24 19:02:53', '2024-03-24 19:02:53', 1708887008, 'first', 'ended', 15, '0'),
(4, 25, 2, 2, 'TIER II', 'BTC', '.5', '24689.55875001', '0.00098333333333333', '0.029499999999993', '0.0295', '2024-02-24 19:02:30', '2024-03-25 19:03:30', 1708887731, 'second', 'ended', 30, '0.52949999999999'),
(8, 35, 8, 1, 'TIER I', 'USDT', '5000', '4998.6625', '8', '120', '120', '2024-06-10 03:06:11', '2024-06-25 03:06:11', 1719680402, 'first', 'ended', 15, '0'),
(9, 42, 2, 1, 'TIER I', 'BTC', '0.11', '6971.66249999', '0.000176', '0.00264', '0.00264', '2024-08-01 19:08:51', '2024-08-16 19:08:51', 1724259601, 'first', 'ended', 15, '0.11264'),
(10, 42, 2, 2, 'TIER II', 'BTC', '0.45', '28521.43312498', '0.000885', '0.01416', '0.02655', '2024-08-01 19:08:41', '2024-08-31 19:08:41', 1724346002, 'second', 'active', 16, ''),
(11, 35, 2, 2, 'TIER II', 'BTC', '0.2', '10866.75375001', '0.00039333333333333', '0.0062933333333329', '0.0118', '2024-08-05 23:08:48', '2024-09-04 23:09:48', 1724605201, 'second', 'active', 16, ''),
(12, 35, 8, 1, 'TIER I', 'USDT', '1000', '999.9275', '1.6', '24', '24', '2024-09-09 09:09:57', '2024-09-24 09:09:57', 1727542801, 'first', 'ended', 15, '0'),
(13, 51, 3, 1, 'TIER I', 'ETH', '.067', '233.6539575', '0.0001072', '0.001608', '0.001608', '2024-11-23 14:11:46', '2024-12-08 14:12:46', 1733594402, 'first', 'ended', 15, '0'),
(14, 35, 3, 1, 'TIER I', 'ETH', '1', '3339.15375', '0.0016', '0.024', '0.024', '2024-11-24 21:11:49', '2024-12-09 21:12:49', 1733724002, 'first', 'ended', 15, '0'),
(15, 35, 2, 4, 'TIER IV', 'BTC', '0.55', '53143.300375', '0.0023161111111111', '0.037057777777777', '0.20845', '2024-12-01 00:12:38', '2025-03-01 00:03:38', 1734804001, 'second', 'active', 16, ''),
(16, 51, 3, 1, 'TIER I', 'ETH', '.068608', '263.7703168', '0.0001097728', '0.001646592', '0.001646592', '2024-12-09 16:12:16', '2024-12-24 16:12:16', 1735365602, 'first', 'ended', 15, '0'),
(17, 37, 2, 1, 'TIER I', 'BTC', '0.067', '7106.99979125', '0.0001072', '0.001608', '0.001608', '2024-12-18 00:12:52', '2025-01-02 00:01:52', 1736056803, 'first', 'ended', 15, '0.068608'),
(18, 51, 3, 1, 'TIER I', 'ETH', '.070254592', '236.81690108', '0.0001124073472', '0.001686110208', '0.001686110208', '2024-12-29 15:12:24', '2025-01-13 15:01:24', 1736920802, 'first', 'ended', 15, '0.071940702208');

-- --------------------------------------------------------

--
-- Table structure for table `invest_plans`
--

CREATE TABLE `invest_plans` (
  `id` int(11) NOT NULL,
  `plan` varchar(255) NOT NULL,
  `min` varchar(255) NOT NULL,
  `max` varchar(255) NOT NULL,
  `monthly` varchar(255) NOT NULL,
  `duration` int(11) NOT NULL,
  `dura` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invest_plans`
--

INSERT INTO `invest_plans` (`id`, `plan`, `min`, `max`, `monthly`, `duration`, `dura`) VALUES
(1, 'TIER I', '200', '7400', '2.4', 15, '15 Days'),
(2, 'TIER II', '7500', '29000', '5.9', 30, '1 month'),
(3, 'TIER III', '30000', '52000', '12.9', 60, '2 Months'),
(4, 'TIER IV', '53000', '900000', '37.9', 90, '3 Months');

-- --------------------------------------------------------

--
-- Table structure for table `personal_documents`
--

CREATE TABLE `personal_documents` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `identity_type` varchar(255) NOT NULL,
  `identity_number` varchar(255) NOT NULL,
  `front` varchar(255) NOT NULL,
  `back` varchar(255) NOT NULL,
  `verified` enum('0','1','2') NOT NULL DEFAULT '0',
  `datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `personal_documents`
--

INSERT INTO `personal_documents` (`id`, `uid`, `identity_type`, `identity_number`, `front`, `back`, `verified`, `datetime`) VALUES
(1, 25, 'national_id', '12345678', '1688456042-1706218701.png', '1688456042-1706218701.png', '1', '2024-01-25 21:38:21'),
(2, 42, 'passport', '1770551454354', 'FC9E34FC-2EBF-48CC-B333-DDFAAD8723B8-1717406986.jpeg', '6AAEED3D-2005-492B-B12E-09A9D646C27C-1717406986.jpeg', '1', '2024-06-03 09:29:46'),
(3, 41, 'national_id', '8351212393', '20231009_084100-1717408076.jpg', '20231009_084118-1717408076.jpg', '1', '2024-06-03 09:47:56'),
(4, 42, 'passport', '16CK88802', '17225417968788048945460044771387-1722541893.jpg', '17225418328448212637328482899605-1722541893.jpg', '1', '2024-08-01 19:51:33');

-- --------------------------------------------------------

--
-- Table structure for table `stakes`
--

CREATE TABLE `stakes` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `wid` int(11) NOT NULL,
  `plan_name` varchar(255) NOT NULL,
  `staked` varchar(255) NOT NULL,
  `expected` varchar(255) NOT NULL,
  `daily_earned` varchar(255) NOT NULL,
  `earned` varchar(255) NOT NULL,
  `available_withdrawal` varchar(255) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `num_of_days` int(11) NOT NULL DEFAULT 1,
  `days_until_withdrawal` int(11) NOT NULL DEFAULT 29,
  `last_updated` int(11) NOT NULL,
  `status` enum('staking','unstaked','ended') NOT NULL DEFAULT 'staking',
  `capital_returned` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stakes`
--

INSERT INTO `stakes` (`id`, `uid`, `plan_id`, `wid`, `plan_name`, `staked`, `expected`, `daily_earned`, `earned`, `available_withdrawal`, `start_date`, `end_date`, `num_of_days`, `days_until_withdrawal`, `last_updated`, `status`, `capital_returned`) VALUES
(17, 25, 7, 18, 'Avalanche staking', '3.90079676', '0.585119514', '0.0016030671616438', '0.008015335808219', '3.90079676', '2024-02-23 13:02:31', '2025-02-22 13:02:31', 2, -184, 1736877602, 'unstaked', '1'),
(20, 25, 2, 2, 'Bitcoin staking', '0.6', '0.174', '0.00047671232876712', '0.10392328767123', '0.010487671232876', '2024-02-23 13:02:42', '2025-02-22 13:02:42', 215, 29, 1736877602, 'staking', '0'),
(22, 41, 2, 2, 'Bitcoin staking', '0.00469032', '0.0013601928', '3.7265556164384E-6', '3.7265556164384E-6', '', '2024-06-20 19:06:17', '2025-06-20 19:06:17', 1, 29, 1718913197, 'staking', '0');

-- --------------------------------------------------------

--
-- Table structure for table `stake_plans`
--

CREATE TABLE `stake_plans` (
  `id` int(11) NOT NULL,
  `plan` varchar(255) NOT NULL,
  `crypto` varchar(255) NOT NULL,
  `apy` varchar(255) NOT NULL,
  `min` varchar(255) NOT NULL,
  `max` varchar(255) NOT NULL,
  `max_val` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stake_plans`
--

INSERT INTO `stake_plans` (`id`, `plan`, `crypto`, `apy`, `min`, `max`, `max_val`) VALUES
(1, 'Solana staking', 'SOL', '22', '1', '2000000', '2M'),
(2, 'Bitcoin staking', 'BTC', '29', '0.002', '500000', '500k'),
(3, 'Etherum Staking', 'ETH', '32', '1', '700000', '700k'),
(4, 'Cordano staking', 'ADA', '30', '200', '1500000', '1.5M'),
(5, 'Polkadot staking', 'DOT', '25', '15', '1500000', '1.5M'),
(6, 'Chainlink staking', 'LINK', '27', '6', '1000000', '1M'),
(7, 'Avalanche staking', 'AVAX', '15', '3', '1200000', '1.2M'),
(8, 'Binance coin staking', 'BNB', '17', '2', '800000', '800K'),
(9, 'XRP staking', 'XRP', '40', '200', '1500000', '1.5M'),
(10, 'Litecoin staking', 'LTC', '50', '2', '900000', '900K');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `account_no` varchar(255) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_pic` varchar(255) NOT NULL,
  `address1` text NOT NULL,
  `address2` text NOT NULL,
  `country` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `timezone` varchar(255) NOT NULL,
  `verify_code` int(11) NOT NULL,
  `referer` varchar(255) NOT NULL,
  `level` enum('1','2','3') NOT NULL DEFAULT '1',
  `admin` enum('0','1') NOT NULL DEFAULT '0',
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `verified` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `account_no`, `phone`, `password`, `profile_pic`, `address1`, `address2`, `country`, `state`, `city`, `timezone`, `verify_code`, `referer`, `level`, `admin`, `datetime`, `verified`) VALUES
(25, 'Ifeanyi', 'Oputa', 'oputalawrence@gmail.com', 'yf-oputa001234567', '09025816161', '321321', 'wallpaperflare-1706297126.jpg', '@24 Lucia Avenue', 'Konoha village', 'Nigeria', 'Delta', 'Asaba', 'Africa/Lagos', 119340, '', '2', '1', '2024-01-23 21:18:46', 1),
(27, 'Alexander', 'Louis', 'alexanderlouis@gmail.com', 'yf-louis009751070', '01658927', 'louis123', '', '', '', '', '', '', '', 416729, '', '1', '0', '2024-02-25 23:01:03', 0),
(33, 'Lawjun', 'Inc', 'lawjun.com@gmail.com', 'yf-inc002988181', '', '123123', '', '', '', '', '', '', '', 658589, '', '1', '0', '2024-03-03 21:00:50', 1),
(35, 'Luis', 'Gomes', 'luis52gomes@gmail.com', 'yf-gomes002965870', '325222997799', '0987654321A', '', '$$$$$', '$$$$', 'Germany', 'Billions ', 'Billions ', 'Africa/Abidjan', 261146, '', '2', '1', '2024-05-21 15:45:13', 1),
(36, 'Emma', 'Susana', 'susanamal987@gmail.com', 'yf-emma003800911', '85487648', '0987654321A', '', 'Germany ', 'Germany ', 'Germany', 'Frankfurt ', 'Frankfurt ', 'Africa/Windhoek', 370160, '', '1', '0', '2024-05-25 18:16:32', 1),
(37, 'Marie', 'Brandie', 'michelle029729@gmail.com', 'yf-marie009701970', '752163542', '0987654321A', 'IMG_20240126_221023_243-1734188466.jpg', 'Germany ', '', 'Germany', 'Berlin ', 'Berlin', '', 159517, '', '2', '0', '2024-05-29 08:11:06', 1),
(38, 'M', 'U', 'rianbyrne29@gmail.com', 'yf-abu006367725', '', '111333', '', '', '', '', '', '', '', 746922, '', '1', '0', '2024-05-31 05:36:46', 0),
(39, 'G', 'U', 'rianbyrne29@gmail.com', 'yf-abi003261471', '', '111333', '', '', '', '', '', '', '', 370465, '', '1', '0', '2024-05-31 05:37:48', 0),
(40, 'U', 'C', 'rianbyrne29@gmail.com', 'yf-abi007129119', '', '111333', '', '', '', '', '', '', '', 785476, '', '1', '0', '2024-05-31 05:38:33', 0),
(41, 'Laszlo ', 'Nagy', 'akical963@gmail.com', 'yf-nagy002230461', '+36', '20GenevA13', '', 'Hungary ', '', 'Hungary', 'PEST', 'Gödöllő', '', 228111, '', '3', '0', '2024-05-31 13:11:43', 1),
(42, 'Veschi ', 'Christophe', 'kriss0830@hotmail.fr', 'yf-christophe008855372', '0672142975', 'Rvnsfnnc2022!', '', 'France', '', 'France', 'Var', 'La crau', '', 185702, '', '3', '0', '2024-05-31 13:26:42', 1),
(43, 'Rian', 'Byrne', 'rian229977@gmail.com', 'yf-byrne004418250', '', '0987654321A', '', '', '', '', '', '', '', 631593, '', '1', '0', '2024-06-05 12:26:34', 0),
(44, 'Gerhard', 'Schreiber', 'gerhard121979@web.de', 'yf-schreiber004954513', '', 'jasmin1234', '', '', '', '', '', '', '', 555203, '', '1', '0', '2024-06-17 18:34:09', 1),
(45, 'Olivia ', 'Olivia', 'petersolivia104@gmail.com', 'yf-olivia009782019', '', '0987654321A', '', '', '', '', '', '', '', 875358, '', '1', '0', '2024-08-27 10:26:43', 1),
(46, 'Scott', 'Scott', 'rianbyrne12@gmail.com', 'yf-scott004089394', '', '0987654321A', '', '', '', '', '', '', '', 905563, '', '1', '0', '2024-08-29 11:30:01', 1),
(47, 'Luís', 'Cláudio', 'lmcclaudio90@gmail.com', 'yf-cláudio008207334', '+351 913342731', '232807Lc#€', '', 'Rua Dr. Miguel Bombarda ', '110', 'Portugal', 'Santarém', 'Couço', 'Europe/Lisbon', 701043, '', '2', '0', '2024-09-16 15:00:29', 1),
(48, 'Carmen', 'Marie', 'rianbyrne29@gmail.com', 'yf-marie001819114', '', '0987654321A', '', '', '', '', '', '', '', 593347, '', '1', '0', '2024-09-20 13:41:57', 1),
(49, 'Chloe', 'Chloe', 'chloecarlson439@gmail.com', 'yf-carlson006827103', '23146', '0987654321A', '', 'Billions ', '', 'Germany', 'Billions ', 'Billions ', '', 749705, '', '2', '0', '2024-11-19 17:39:27', 1),
(50, 'Michelle', 'Michelle', 'byrnerian65@gmail.com', 'yf-michelle006733750', '', '0987654321A', '', '', '', '', '', '', '', 190555, '', '1', '0', '2024-11-20 15:24:29', 1),
(51, 'Kai', 'Karlsson', 'homersboss@yahoo.com', 'yf-karlsson009455396', '6268412734', '99RandompaSS!!', '', '1550 Navigator Dr', '', 'United States', 'Az', 'Lake Havasu City', 'America/Phoenix', 873366, '', '2', '0', '2024-11-22 14:54:05', 1),
(52, 'Bombom', 'Nyash', 'bombomnyash@gmail.com', 'yf-nyash008392631', '', '321321', '', '', '', '', '', '', '', 620200, 'yf-oputa001234567', '1', '0', '2024-12-08 14:48:03', 1),
(53, 'Mia', 'Mia', 'Johansenmia718@gmail.com', 'yf-mia008757023', '85218467979', '0987654321A', '', 'Dollars', '', 'United States', 'Texas', 'Texas', '', 135097, 'yf-gomes002965870', '2', '0', '2024-12-11 00:12:25', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_wallets`
--

CREATE TABLE `user_wallets` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `wallet_id` int(11) NOT NULL,
  `wallet_name` varchar(255) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_wallets`
--

INSERT INTO `user_wallets` (`id`, `uid`, `wallet_id`, `wallet_name`, `datetime`) VALUES
(47, 26, 2, 'BTC', '2024-02-01 19:29:23'),
(49, 26, 1, 'USD', '2024-02-02 11:20:56'),
(51, 25, 1, 'USD', '2024-02-03 21:33:31'),
(56, 26, 4, 'EUR', '2024-02-19 20:47:06'),
(57, 26, 6, 'DODGE', '2024-02-19 20:47:07'),
(58, 26, 8, 'USDT', '2024-02-19 20:47:09'),
(70, 25, 18, 'AVAX', '2024-02-27 19:58:12'),
(71, 33, 1, 'USD', '2024-03-07 00:10:37'),
(73, 35, 2, 'BTC', '2024-05-28 00:35:20'),
(74, 35, 3, 'ETH', '2024-05-28 00:35:24'),
(75, 35, 7, 'USDC', '2024-05-28 00:35:28'),
(76, 35, 8, 'USDT', '2024-05-28 00:35:29'),
(77, 36, 2, 'BTC', '2024-05-28 08:02:40'),
(78, 36, 8, 'USDT', '2024-05-28 08:02:58'),
(79, 36, 3, 'ETH', '2024-05-28 08:03:16'),
(80, 42, 2, 'BTC', '2024-06-03 09:16:53'),
(81, 42, 8, 'USDT', '2024-06-03 09:17:08'),
(82, 42, 3, 'ETH', '2024-06-03 09:17:15'),
(83, 41, 8, 'USDT', '2024-06-03 09:32:05'),
(84, 41, 3, 'ETH', '2024-06-03 09:32:24'),
(85, 41, 2, 'BTC', '2024-06-03 09:32:26'),
(86, 44, 2, 'BTC', '2024-06-17 20:57:28'),
(87, 44, 3, 'ETH', '2024-06-17 20:59:23'),
(88, 44, 8, 'USDT', '2024-06-17 20:59:34'),
(89, 44, 11, 'BNB', '2024-06-17 20:59:52'),
(90, 41, 12, 'LTC', '2024-06-20 19:41:52'),
(91, 47, 4, 'EUR', '2024-09-16 15:02:46'),
(92, 47, 2, 'BTC', '2024-09-16 15:02:49'),
(93, 47, 1, 'USD', '2024-09-16 15:02:50'),
(94, 51, 3, 'ETH', '2024-11-22 14:58:32'),
(95, 52, 1, 'USD', '2024-12-08 16:22:30'),
(96, 52, 2, 'BTC', '2024-12-08 16:22:32'),
(97, 53, 8, 'USDT', '2024-12-11 00:15:21'),
(98, 53, 2, 'BTC', '2024-12-11 00:15:24'),
(99, 37, 2, 'BTC', '2024-12-14 15:03:31');

-- --------------------------------------------------------

--
-- Table structure for table `wallets`
--

CREATE TABLE `wallets` (
  `id` int(11) NOT NULL,
  `wallet_name` varchar(255) NOT NULL,
  `wallet_fullname` varchar(255) NOT NULL,
  `wallet_type` enum('Fiat','Crypto') NOT NULL,
  `wallet_img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wallets`
--

INSERT INTO `wallets` (`id`, `wallet_name`, `wallet_fullname`, `wallet_type`, `wallet_img`) VALUES
(1, 'USD', 'US Dollars', 'Fiat', 'icons8-us-dollar-64.png'),
(2, 'BTC', 'Bitcoin', 'Crypto', '1661050287.png'),
(3, 'ETH', 'Etherum', 'Crypto', '1671520294.png'),
(4, 'EUR', 'Euros', 'Fiat', 'icons8-euro-64.png'),
(5, 'GBP', 'Great Britain Pounds', 'Fiat', 'icons8-british-pound-64.png'),
(6, 'DOGE', 'Dogecoin', 'Crypto', '1671523566.png'),
(7, 'USDC', 'USD coin', 'Crypto', 'usd-coin-usdc-logo.png'),
(8, 'USDT', 'Tether', 'Crypto', 'usdt.png'),
(9, 'ADA', 'Cordano', 'Crypto', 'ada.png'),
(10, 'SHIB', 'Shiba Inu', 'Crypto', 'shib.png'),
(11, 'BNB', 'Binance coin', 'Crypto', 'bnb.png'),
(12, 'LTC', 'Litecoin', 'Crypto', '1660982923.png'),
(13, 'SOL', 'Solana', 'Crypto', 'solana.png'),
(14, 'LINK', 'Chainlink', 'Crypto', 'link.png'),
(15, 'DOT', 'Polkadot', 'Crypto', 'polkadot.png'),
(16, 'MATIC', 'Polygon', 'Crypto', 'matic.png'),
(17, 'TRX', 'Tron', 'Crypto', 'tron.png'),
(18, 'AVAX', 'Avalanche', 'Crypto', 'avax.png'),
(19, 'XRP', 'XRP', 'Crypto', 'xrp.png');

-- --------------------------------------------------------

--
-- Table structure for table `wallet_address`
--

CREATE TABLE `wallet_address` (
  `id` int(11) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `network` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wallet_address`
--

INSERT INTO `wallet_address` (`id`, `currency`, `address`, `network`) VALUES
(1, 'BTC', 'bc1qdhmv7c6702uhhrshqq9uyfa6sp7g2vzyy0fs97', ''),
(2, 'BNB', '0x420e7955eB650C9cCE17055a7f657F879F0C2Ad4', ''),
(3, 'USDT', 'TB8LB4PgHNgEhaiiittpYA7seoPKfdarvp', 'TRC20'),
(4, 'USDT', '0x420e7955eB650C9cCE17055a7f657F879F0C2Ad4', 'ERC20'),
(5, 'ETH', '0x420e7955eB650C9cCE17055a7f657F879F0C2Ad4', '');

-- --------------------------------------------------------

--
-- Table structure for table `withdrawals`
--

CREATE TABLE `withdrawals` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `wallet_id` int(11) NOT NULL,
  `wallet_name` varchar(255) NOT NULL,
  `crypto_address` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `verified` enum('0','1','2') NOT NULL DEFAULT '0',
  `from_to` varchar(255) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `transaction_type` varchar(25) NOT NULL DEFAULT 'withdrawal',
  `datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `withdrawals`
--

INSERT INTO `withdrawals` (`id`, `uid`, `wallet_id`, `wallet_name`, `crypto_address`, `amount`, `verified`, `from_to`, `notes`, `transaction_type`, `datetime`) VALUES
(50, 35, 2, 'BTC', NULL, '0.1', '1', NULL, NULL, 'exchange from', '2024-05-28 00:59:00'),
(51, 41, 8, 'USDT', '0x29E1617b1F09a81c2c01D1119B444d2CE12f012E', '305', '2', NULL, NULL, 'withdrawal', '2024-06-05 05:06:43'),
(52, 35, 8, 'USDT', NULL, '5000', '1', NULL, NULL, 'investment', '2024-06-10 03:18:11'),
(53, 41, 8, 'USDT', NULL, '305', '1', NULL, NULL, 'exchange from', '2024-06-20 19:49:59'),
(54, 41, 2, 'BTC', NULL, '0.00469032', '1', NULL, NULL, 'staking', '2024-06-20 19:53:17'),
(55, 42, 2, 'BTC', NULL, '0.11', '1', NULL, NULL, 'investment', '2024-08-01 19:55:51'),
(56, 42, 2, 'BTC', NULL, '0.45', '1', NULL, NULL, 'investment', '2024-08-01 19:58:41'),
(57, 35, 2, 'BTC', NULL, '0.2', '1', NULL, NULL, 'investment', '2024-08-05 23:45:48'),
(58, 35, 8, 'USDT', NULL, '1000', '1', NULL, NULL, 'investment', '2024-09-09 09:10:57'),
(59, 51, 3, 'ETH', NULL, '.067', '1', NULL, NULL, 'investment', '2024-11-23 14:41:46'),
(60, 35, 3, 'ETH', NULL, '1', '1', NULL, NULL, 'investment', '2024-11-24 21:24:49'),
(61, 35, 2, 'BTC', NULL, '0.55', '1', NULL, NULL, 'investment', '2024-12-01 00:25:38'),
(62, 51, 3, 'ETH', NULL, '.068608', '1', NULL, NULL, 'investment', '2024-12-09 16:31:16'),
(64, 37, 2, 'BTC', NULL, '0.067', '1', NULL, NULL, 'investment', '2024-12-18 00:58:52'),
(65, 51, 3, 'ETH', NULL, '.070254592', '1', NULL, NULL, 'investment', '2024-12-29 15:31:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `deposits`
--
ALTER TABLE `deposits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uid` (`uid`),
  ADD KEY `wallet_id_2` (`wallet_id`);

--
-- Indexes for table `investments`
--
ALTER TABLE `investments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invest_plans`
--
ALTER TABLE `invest_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_documents`
--
ALTER TABLE `personal_documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `stakes`
--
ALTER TABLE `stakes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stake_plans`
--
ALTER TABLE `stake_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_wallets`
--
ALTER TABLE `user_wallets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_wallets_ibfk_1` (`uid`),
  ADD KEY `user_wallets_ibfk_2` (`wallet_id`);

--
-- Indexes for table `wallets`
--
ALTER TABLE `wallets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wallet_address`
--
ALTER TABLE `wallet_address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uid` (`uid`),
  ADD KEY `wallet_id` (`wallet_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `deposits`
--
ALTER TABLE `deposits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT for table `investments`
--
ALTER TABLE `investments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `invest_plans`
--
ALTER TABLE `invest_plans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `personal_documents`
--
ALTER TABLE `personal_documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `stakes`
--
ALTER TABLE `stakes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `stake_plans`
--
ALTER TABLE `stake_plans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `user_wallets`
--
ALTER TABLE `user_wallets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `wallets`
--
ALTER TABLE `wallets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `wallet_address`
--
ALTER TABLE `wallet_address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `withdrawals`
--
ALTER TABLE `withdrawals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `deposits`
--
ALTER TABLE `deposits`
  ADD CONSTRAINT `deposits_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `deposits_ibfk_3` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`);

--
-- Constraints for table `personal_documents`
--
ALTER TABLE `personal_documents`
  ADD CONSTRAINT `personal_documents_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_wallets`
--
ALTER TABLE `user_wallets`
  ADD CONSTRAINT `user_wallets_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`id`) ON DELETE NO ACTION,
  ADD CONSTRAINT `user_wallets_ibfk_2` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`) ON DELETE NO ACTION;

--
-- Constraints for table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD CONSTRAINT `withdrawals_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `withdrawals_ibfk_3` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
