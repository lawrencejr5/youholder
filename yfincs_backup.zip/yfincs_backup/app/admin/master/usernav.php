<div class="box">
    <div class="panel-body ml-20">
        <ul class="nav nav-tabs cus f-14" role="tablist">
            <li class="nav-item">
                <a class="nav-link" href="../users/profile.php?userid=<?= $_GET['userid'] ?>">Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link " href="../users/transactions.php?userid=<?= $_GET['userid'] ?>">Transactions</a>
            </li>
            <li class="nav-item">
                <a class="nav-link " href="../users/wallets.php?userid=<?= $_GET['userid'] ?>">Wallets</a>
            </li>
            <li class="nav-item">
                <a class="nav-link " href="../users/stakes.php?userid=<?= $_GET['userid'] ?>">Stakings</a>
            </li>
            <li class="nav-item">
                <a class="nav-link " href="../users/investments.php?userid=<?= $_GET['userid'] ?>">Investments</a>
            </li>
        </ul>
        <div class="clearfix"></div>
    </div>
</div>