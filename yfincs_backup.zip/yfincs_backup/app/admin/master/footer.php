<div class="pull-right hidden-xs f-14">
    <b>Version</b> 4.1.1
</div>
<strong class="f-14">Copyright &copy; 2024 <a href="#" target="_blank">YieldFincs</a> | </strong> <span class="f-14">All rights reserved</span>
